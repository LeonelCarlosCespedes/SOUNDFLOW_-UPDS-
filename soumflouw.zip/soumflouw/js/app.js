// RETO 2: Datos de Música y Videos separados en arreglos
const catalogoMusica = [
    { id: 1, titulo: "Goteo", artista: "Duki", tipo: "Música", duracion: "2:44", img: "img/album/1.jpg" },
    { id: 2, titulo: "LALA", artista: "Myke Towers", tipo: "Música", duracion: "3:17", img: "img/album/2.jpg" },
    { id: 3, titulo: "Una Foto Remix", artista: "Mesita, Nicki Nicole", tipo: "Música", duracion: "4:10", img: "img/album/3.jpg" }
];

const catalogoVideos = [
    { id: 101, titulo: "Goteo (Video Oficial)", artista: "Duki", tipo: "Video HD", duracion: "3:05", img: "img/blog/1.jpg" },
    { id: 102, titulo: "LALA (Official Video)", artista: "Myke Towers", tipo: "Video HD", duracion: "3:40", img: "img/blog/2.jpg" }
];

window.addEventListener("load", () => {
    let modoActual = "musica"; // 'musica' o 'video'

    // Elementos del DOM
    const btnMusica = document.getElementById("btn-modo-musica");
    const btnVideo = document.getElementById("btn-modo-video");
    const heroTitle = document.getElementById("hero-title");
    const heroSubtitle = document.getElementById("hero-subtitle");
    const catalogoTitulo = document.getElementById("catalogo-titulo");
    const contenedorTarjetas = document.getElementById("contenedor-tarjetas");
    
    const playerTitle = document.getElementById("player-title");
    const playerArtist = document.getElementById("player-artist");
    const btnPlayerAction = document.getElementById("btn-player-action");
    const btnPlayHero = document.getElementById("btn-play-hero");

    // Función para renderizar tarjetas según el modo activo
    function renderizarCatálogo(lista) {
        contenedorTarjetas.innerHTML = ""; // Limpia el contenedor
        
        lista.forEach(item => {
            const col = document.createElement("div");
            col.className = "col-md-4";
            col.innerHTML = `
                <div class="music-card text-center">
                    <img src="${item.img}" alt="${item.titulo}" onerror="this.src='img/hero-bg.png'">
                    <h5 style="color: #fff; margin-bottom: 5px;">${item.titulo}</h5>
                    <p style="color: #b3b3b3; font-size: 14px; margin-bottom: 10px;">${item.artista} • ${item.duracion}</p>
                    <button class="site-btn btn-reproducir-card" data-id="${item.id}" style="padding: 6px 15px; font-size: 12px;">
                        ${modoActual === "musica" ? "🎵 Escuchar" : "🎬 Ver Video"}
                    </button>
                </div>
            `;
            contenedorTarjetas.appendChild(col);
        });

        // Evento click en los botones de las tarjetas
        document.querySelectorAll(".btn-reproducir-card").forEach(btn => {
            btn.addEventListener("click", (e) => {
                e.preventDefault();
                const itemId = parseInt(btn.getAttribute("data-id"));
                const seleccionado = lista.find(el => el.id === itemId);
                
                if (seleccionado) {
                    reproducirItem(seleccionado);
                }
            });
        });
    }

    function reproducirItem(item) {
        playerTitle.textContent = `${modoActual === "musica" ? "🎵" : "🎬"} ${item.titulo}`;
        playerArtist.textContent = `${item.artista} — ${item.duracion}`;
        btnPlayerAction.textContent = "PAUSAR ❚❚";
    }

    // RETO 3 y 4: Eventos para alternar entre MÚSICA y VIDEO (Manipulación del DOM)
    btnMusica.addEventListener("click", (e) => {
        e.preventDefault();
        modoActual = "musica";
        btnMusica.classList.add("active");
        btnVideo.classList.remove("active");

        heroTitle.innerHTML = "<span>SoundFlow:</span> Escucha tus canciones favoritas";
        heroSubtitle.textContent = "Música en streaming sin interrupciones.";
        catalogoTitulo.textContent = "Canciones Destacadas";

        renderizarCatálogo(catalogoMusica);
    });

    btnVideo.addEventListener("click", (e) => {
        e.preventDefault();
        modoActual = "video";
        btnVideo.classList.add("active");
        btnMusica.classList.remove("active");

        heroTitle.innerHTML = "<span>SoundFlow:</span> Mira los mejores videos musicales";
        heroSubtitle.textContent = "Sesiones en vivo y videoclips oficiales en HD.";
        catalogoTitulo.textContent = "Videos Musicales Destacados";

        renderizarCatálogo(catalogoVideos);
    });

    // Reproducir elemento principal
    btnPlayHero.addEventListener("click", (e) => {
        e.preventDefault();
        const listaActual = modoActual === "musica" ? catalogoMusica : catalogoVideos;
        reproducirItem(listaActual[0]);
    });

    // Carga inicial (Modo Música)
    renderizarCatálogo(catalogoMusica);
});