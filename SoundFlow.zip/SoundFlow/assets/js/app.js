const API_URL = 'api/canciones.php';
let paginaActual = 1;
let catalogoMusica = [];
let resultadosBusqueda = [];
let indiceActual = 0;
let reproduciendo = false;
let usandoAudioRespaldo = false;
let vistaActual = 'inicio';
const audio = new Audio();
audio.volume = 0.7;

const $ = (id) => document.getElementById(id);
const refs = {};

document.addEventListener('DOMContentLoaded', () => {
    Object.assign(refs, {
        menu: $('menuPrincipal'), sidebar: $('sidebar'), btnMenuMobile: $('btnMenuMobile'), menuBackdrop: $('menuBackdrop'),
        listaInicio: $('listaInicio'), lista: $('listaCanciones'), paginacion: $('paginacion'),
        resultadosBusqueda: $('resultadosBusqueda'), textoBusqueda: $('textoBusqueda'), buscador: $('buscador'),
        listaBiblioteca: $('listaBiblioteca'), listaPlaylists: $('listaPlaylists'), detallePlaylist: $('detallePlaylist'),
        playlistInicio: $('playlistInicio'), playlistCrearPanel: $('playlistCrearPanel'), playlistPasoCrear: $('playlistPasoCrear'), playlistEditor: $('playlistEditor'),
        btnNuevaPlaylist: $('btnNuevaPlaylist'), nombrePlaylist: $('nombrePlaylist'), btnCrearPlaylist: $('btnCrearPlaylist'), mensajePlaylist: $('mensajePlaylist'),
        listaArtistas: $('listaArtistas'), detalleArtista: $('detalleArtista'),
        form: $('formCancion'), cancionId: $('cancionId'), titulo: $('titulo'), artista: $('artista'), album: $('album'),
        genero: $('genero'), imagenUrl: $('imagenUrl'), audioArchivo: $('audioArchivo'), mensaje: $('mensajeFormulario'),
        tituloFormulario: $('tituloFormulario'), btnGuardar: $('btnGuardarCancion'), btnCancelar: $('btnCancelarEdicion'),
        playerTitulo: $('playerTitulo'), playerArtista: $('playerArtista'), playerImagen: $('playerImagen'),
        btnPlayer: $('btnPlayer'), btnAnterior: $('btnAnterior'), btnSiguiente: $('btnSiguiente'),
        btnLike: $('btnLike'), barraProgreso: $('barraProgreso'), controlVolumen: $('controlVolumen'),
        tiempoActual: $('tiempoActual'), duracionTotal: $('duracionTotal')
    });

    instalarEventos();
    inicializarPlaylists();
    cargarCanciones();
    mostrarVista('inicio');
});

function instalarEventos() {
    refs.menu?.addEventListener('click', (e) => {
        const boton = e.target.closest('[data-view]');
        if (!boton) return;
        mostrarVista(boton.dataset.view);
    });

    refs.btnMenuMobile?.addEventListener('click', alternarMenuMobile);
    refs.menuBackdrop?.addEventListener('click', cerrarMenuMobile);
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') cerrarMenuMobile(); });
    window.addEventListener('resize', () => { if (window.innerWidth > 900) cerrarMenuMobile(); });

    refs.buscador?.addEventListener('input', (e) => buscarCanciones(e.target.value.trim()));
    refs.form?.addEventListener('submit', guardarCancion);
    refs.btnCancelar?.addEventListener('click', () => prepararNueva());
    refs.btnNuevaPlaylist?.addEventListener('click', mostrarCreadorPlaylist);
    refs.btnCrearPlaylist?.addEventListener('click', crearPlaylist);
    refs.nombrePlaylist?.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); crearPlaylist(); }
    });

    const contenidoPrincipal = document.querySelector('.main-content');

    contenidoPrincipal?.addEventListener('click', (e) => {
        const play = e.target.closest('.play-button');
        const editar = e.target.closest('.btn-editar');
        const eliminar = e.target.closest('.btn-eliminar');
        const favorito = e.target.closest('.btn-favorito-card');
        const playlist = e.target.closest('.playlist-card[data-playlist-id]');
        const artista = e.target.closest('[data-artista]');
        const agregarResultado = e.target.closest('.btn-agregar-playlist-cancion');
        const quitarPlaylist = e.target.closest('.btn-quitar-playlist');
        const eliminarPlaylistBtn = e.target.closest('#btnEliminarPlaylist');
        const volverPlaylists = e.target.closest('.btn-volver-playlists');

        if (play) reproducirPorId(Number(play.dataset.id));
        if (editar) editarCancion(Number(editar.dataset.id));
        if (eliminar) eliminarCancion(Number(eliminar.dataset.id));
        if (favorito) toggleFavorito(Number(favorito.dataset.id));
        if (playlist) abrirPlaylist(playlist.dataset.playlistId);
        if (artista) abrirArtista(artista.dataset.artista);
        if (agregarResultado) agregarCancionAPlaylist(agregarResultado.dataset.playlistId, Number(agregarResultado.dataset.id));
        if (quitarPlaylist) quitarCancionDePlaylist(quitarPlaylist.dataset.playlistId, Number(quitarPlaylist.dataset.id));
        if (eliminarPlaylistBtn) eliminarPlaylist(eliminarPlaylistBtn.dataset.playlistId);
        if (volverPlaylists) mostrarListaPlaylists();
    });

    let temporizadorBusquedaPlaylist;
    contenidoPrincipal?.addEventListener('input', (e) => {
        const input = e.target.closest('#buscarCancionPlaylist');
        if (!input) return;
        clearTimeout(temporizadorBusquedaPlaylist);
        temporizadorBusquedaPlaylist = setTimeout(() => {
            buscarCancionesParaPlaylist(input.dataset.playlistId, input.value.trim());
        }, 220);
    });

    refs.btnPlayer?.addEventListener('click', () => reproduciendo ? pausarCancion() : reproducirCancion());
    refs.btnSiguiente?.addEventListener('click', siguienteCancion);
    refs.btnAnterior?.addEventListener('click', anteriorCancion);
    refs.btnLike?.addEventListener('click', toggleFavoritoActual);

    refs.barraProgreso?.addEventListener('input', () => {
        if (audio.duration) audio.currentTime = (Number(refs.barraProgreso.value) / 100) * audio.duration;
    });
    refs.controlVolumen?.addEventListener('input', () => audio.volume = Number(refs.controlVolumen.value));

    audio.addEventListener('timeupdate', actualizarProgreso);
    audio.addEventListener('ended', siguienteCancion);
}

function alternarMenuMobile() {
    const abierto = refs.sidebar?.classList.toggle('abierta');
    refs.menuBackdrop?.classList.toggle('activo', Boolean(abierto));
    refs.btnMenuMobile?.setAttribute('aria-expanded', abierto ? 'true' : 'false');
    document.body.classList.toggle('menu-movil-abierto', Boolean(abierto));
}

function cerrarMenuMobile() {
    refs.sidebar?.classList.remove('abierta');
    refs.menuBackdrop?.classList.remove('activo');
    refs.btnMenuMobile?.setAttribute('aria-expanded', 'false');
    document.body.classList.remove('menu-movil-abierto');
}

function mostrarVista(nombre) {
    vistaActual = nombre;
    document.querySelectorAll('.vista').forEach(v => v.classList.remove('activa'));
    $(`vista-${nombre}`)?.classList.add('activa');
    refs.menu?.querySelectorAll('[data-view]').forEach(b => b.classList.toggle('active', b.dataset.view === nombre));

    if (nombre === 'biblioteca') renderizarBiblioteca();
    if (nombre === 'playlists') mostrarListaPlaylists();
    if (nombre === 'artistas') renderizarArtistas();
    if (nombre === 'agregar' && !refs.cancionId.value) prepararNueva();
    if (nombre === 'buscar') setTimeout(() => refs.buscador?.focus(), 50);

    cerrarMenuMobile();
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

async function solicitarJson(url, opciones = {}) {
    const respuesta = await fetch(url, opciones);
    let json;
    try {
        json = await respuesta.json();
    } catch {
        throw new Error(`El servidor respondió HTTP ${respuesta.status}, pero no devolvió JSON válido.`);
    }
    if (!respuesta.ok || json.success === false) {
        const detalle = Array.isArray(json.errors) ? json.errors.join(' ') : '';
        throw new Error(json.error || detalle || `Error HTTP ${respuesta.status}`);
    }
    return json;
}

async function cargarCanciones() {
    if (refs.lista) refs.lista.innerHTML = estadoCarga('Consultando catálogo...');
    if (refs.listaInicio) refs.listaInicio.innerHTML = estadoCarga('Cargando música...');

    const params = new URLSearchParams({ page: paginaActual, search: '' });
    try {
        const json = await solicitarJson(`${API_URL}?${params.toString()}`);
        catalogoMusica = json.data || [];
        renderizarCanciones(catalogoMusica, refs.lista, { accionesCrud: true });
        renderizarCanciones(catalogoMusica.slice(0, 4), refs.listaInicio, { accionesCrud: false });
        renderizarPaginacion(json.meta || { page: 1, pages: 1, total: catalogoMusica.length });

        if (catalogoMusica.length && !audio.src) cargarCancion(0);
        renderizarBiblioteca();
        renderizarPlaylists();
        renderizarArtistas();
    } catch (error) {
        console.error('[cargarCanciones]', error);
        const html = `<div class="sin-resultados"><i class="fas fa-triangle-exclamation"></i><strong>No se pudo conectar con la API.</strong><span>${escaparHtml(error.message)}</span></div>`;
        if (refs.lista) refs.lista.innerHTML = html;
        if (refs.listaInicio) refs.listaInicio.innerHTML = html;
        renderizarPaginacion({ pages: 1 });
    }
}

async function buscarCanciones(texto) {
    if (!texto) {
        resultadosBusqueda = [];
        refs.resultadosBusqueda.innerHTML = '';
        refs.textoBusqueda.textContent = 'Escribe algo para comenzar.';
        return;
    }

    refs.textoBusqueda.textContent = `Buscando “${texto}”...`;
    refs.resultadosBusqueda.innerHTML = estadoCarga('Buscando...');

    try {
        const params = new URLSearchParams({ page: 1, search: texto });
        const json = await solicitarJson(`${API_URL}?${params.toString()}`);
        resultadosBusqueda = json.data || [];
        refs.textoBusqueda.textContent = `${json.meta?.total ?? resultadosBusqueda.length} resultado(s) para “${texto}”`;
        renderizarCanciones(resultadosBusqueda, refs.resultadosBusqueda, { accionesCrud: false });
    } catch (error) {
        refs.resultadosBusqueda.innerHTML = `<div class="sin-resultados"><strong>Error al buscar.</strong><span>${escaparHtml(error.message)}</span></div>`;
    }
}

function renderizarCanciones(lista, contenedor, opciones = {}) {
    if (!contenedor) return;
    if (!lista.length) {
        contenedor.innerHTML = '<div class="sin-resultados"><i class="fas fa-music"></i><strong>No se encontraron canciones.</strong></div>';
        return;
    }

    const favoritosIds = favoritos();
    contenedor.innerHTML = lista.map((c, i) => {
        const esFavorita = favoritosIds.includes(Number(c.id));
        const botonQuitar = opciones.playlistId && opciones.playlistId !== 'favoritas'
            ? `<button class="btn-card btn-quitar-playlist" data-playlist-id="${escaparAtributo(opciones.playlistId)}" data-id="${Number(c.id)}"><i class="fas fa-minus"></i> Quitar</button>`
            : '';
        return `
        <article class="card" data-id="${Number(c.id)}">
            <div class="card-image">
                <img src="${escaparAtributo(c.imagen_url || imagenLocal(i))}" alt="Portada de ${escaparAtributo(c.titulo)}" onerror="this.src='${imagenLocal(i)}'">
                <button class="play-button" data-id="${Number(c.id)}" title="Reproducir"><i class="fas fa-play"></i></button>
                <button class="btn-favorito-card ${esFavorita ? 'favorito' : ''}" data-id="${Number(c.id)}" title="Guardar en biblioteca"><i class="${esFavorita ? 'fas' : 'far'} fa-heart"></i></button>
            </div>
            <div class="card-info">
                <h3>${escaparHtml(c.titulo)}</h3>
                <p>${escaparHtml(c.artista)}</p>
                <small>${escaparHtml(c.album || 'Sin álbum')} ${c.genero ? '• ' + escaparHtml(c.genero) : ''}</small>
                ${opciones.accionesCrud ? `
                <div class="card-actions">
                    <button class="btn-card btn-editar" data-id="${Number(c.id)}"><i class="fas fa-pen"></i> Editar</button>
                    <button class="btn-card btn-eliminar" data-id="${Number(c.id)}"><i class="fas fa-trash"></i> Eliminar</button>
                </div>` : ''}
                ${botonQuitar ? `<div class="card-actions">${botonQuitar}</div>` : ''}
            </div>
        </article>`;
    }).join('');
}

function renderizarPaginacion(meta) {
    if (!refs.paginacion) return;
    const paginas = Number(meta.pages || 1);
    if (paginas <= 1) { refs.paginacion.innerHTML = ''; return; }
    let html = `<button ${paginaActual <= 1 ? 'disabled' : ''} data-page="${paginaActual - 1}">‹</button>`;
    for (let p = 1; p <= paginas; p++) {
        if (p === 1 || p === paginas || Math.abs(p - paginaActual) <= 2) {
            html += `<button class="${p === paginaActual ? 'active' : ''}" data-page="${p}">${p}</button>`;
        }
    }
    html += `<button ${paginaActual >= paginas ? 'disabled' : ''} data-page="${paginaActual + 1}">›</button>`;
    refs.paginacion.innerHTML = html;
    refs.paginacion.querySelectorAll('button[data-page]:not([disabled])').forEach(btn => {
        btn.addEventListener('click', () => {
            paginaActual = Number(btn.dataset.page);
            cargarCanciones();
        });
    });
}

async function guardarCancion(e) {
    e.preventDefault();

    const datosBase = {
        titulo: refs.titulo.value,
        artista: refs.artista.value,
        album: refs.album.value
    };

    const validacion = typeof validarCancion === 'function'
        ? validarCancion(datosBase)
        : { esValido: true, errores: [], datosLimpios: datosBase };

    if (!validacion.esValido) {
        mostrarMensaje(validacion.errores.join(' '), 'error');
        return;
    }

    const id = Number(refs.cancionId.value || 0);
    const existente = encontrarCancion(id);

    refs.btnGuardar.disabled = true;
    mostrarMensaje(id ? 'Actualizando...' : 'Subiendo MP3 y guardando...', 'aviso');

    try {
        let json;

        if (!id) {
            const archivo = refs.audioArchivo?.files?.[0];
            if (!archivo) throw new Error('Selecciona un archivo MP3.');
            if (!archivo.name.toLowerCase().endsWith('.mp3')) throw new Error('El archivo debe ser MP3.');

            const formData = new FormData();
            formData.append('titulo', validacion.datosLimpios.titulo);
            formData.append('artista', validacion.datosLimpios.artista);
            formData.append('album', validacion.datosLimpios.album || '');
            formData.append('genero', refs.genero.value.trim());
            formData.append('duracion', '0:00');
            formData.append('imagen_url', refs.imagenUrl.value.trim() || 'img/songs/1.jpg');
            formData.append('audio', archivo);

            json = await solicitarJson(API_URL, {
                method: 'POST',
                headers: { Accept: 'application/json' },
                body: formData
            });
        } else {
            const datos = {
                ...validacion.datosLimpios,
                genero: refs.genero.value.trim(),
                duracion: existente?.duracion || '0:00',
                imagen_url: refs.imagenUrl.value.trim() || 'img/songs/1.jpg',
                audio_url: existente?.audio_url || 'audio/cancion1.mp3',
                id
            };

            json = await solicitarJson(API_URL, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
                body: JSON.stringify(datos)
            });
        }

        mostrarMensaje(json.message || 'Canción guardada correctamente.', 'exito');
        prepararNueva();
        paginaActual = 1;
        await cargarCanciones();
        mostrarVista('musica');
    } catch (error) {
        mostrarMensaje(error.message, 'error');
    } finally {
        refs.btnGuardar.disabled = false;
    }
}

function editarCancion(id) {
    const c = encontrarCancion(id);
    if (!c) return;
    refs.cancionId.value = c.id;
    refs.titulo.value = c.titulo || '';
    refs.artista.value = c.artista || '';
    refs.album.value = c.album || '';
    refs.genero.value = c.genero || '';
    refs.imagenUrl.value = c.imagen_url || '';
    refs.tituloFormulario.textContent = 'Editar canción';
    refs.btnGuardar.innerHTML = '<i class="fas fa-floppy-disk"></i> ACTUALIZAR CANCIÓN';
    refs.btnCancelar.hidden = false;
    refs.mensaje.textContent = '';
    mostrarVista('agregar');
}

function prepararNueva() {
    refs.form?.reset();
    refs.cancionId.value = '';
    refs.tituloFormulario.textContent = 'Agregar canción';
    refs.btnGuardar.innerHTML = '<i class="fas fa-plus"></i> AGREGAR CANCIÓN';
    refs.btnCancelar.hidden = true;
    refs.mensaje.textContent = '';
}

async function eliminarCancion(id) {
    const c = encontrarCancion(id);
    if (!confirm(`¿Eliminar "${c?.titulo || 'esta canción'}"?`)) return;
    try {
        const json = await solicitarJson(`${API_URL}?id=${id}`, { method: 'DELETE' });
        if (!json.deleted) throw new Error('No se eliminó ningún registro.');
        quitarFavoritoSiExiste(id);
        quitarCancionDeTodasLasPlaylists(id);
        await cargarCanciones();
    } catch (error) {
        alert('Error al eliminar: ' + error.message);
    }
}

function mostrarMensaje(texto, tipo) {
    if (!refs.mensaje) return;
    refs.mensaje.textContent = texto;
    refs.mensaje.className = `mensaje-formulario mensaje-${tipo}`;
}

function favoritos() {
    try { return JSON.parse(localStorage.getItem('soundflow_favoritos') || '[]').map(Number); }
    catch { return []; }
}

function guardarFavoritos(lista) {
    localStorage.setItem('soundflow_favoritos', JSON.stringify([...new Set(lista.map(Number))]));
}

function toggleFavorito(id) {
    const lista = favoritos();
    const pos = lista.indexOf(Number(id));
    if (pos >= 0) lista.splice(pos, 1); else lista.push(Number(id));
    guardarFavoritos(lista);
    renderizarCanciones(catalogoMusica, refs.lista, { accionesCrud: true });
    renderizarCanciones(catalogoMusica.slice(0, 4), refs.listaInicio, { accionesCrud: false });
    if (resultadosBusqueda.length) renderizarCanciones(resultadosBusqueda, refs.resultadosBusqueda, { accionesCrud: false });
    renderizarBiblioteca();
    renderizarPlaylists();
    actualizarFavoritoVisual();
}

function toggleFavoritoActual() {
    const c = catalogoMusica[indiceActual];
    if (c) toggleFavorito(Number(c.id));
}

function quitarFavoritoSiExiste(id) {
    guardarFavoritos(favoritos().filter(x => x !== Number(id)));
}

function renderizarBiblioteca() {
    if (!refs.listaBiblioteca) return;
    const ids = favoritos();
    const lista = catalogoMusica.filter(c => ids.includes(Number(c.id)));
    if (!lista.length) {
        refs.listaBiblioteca.innerHTML = '<div class="sin-resultados"><i class="far fa-heart"></i><strong>Tu biblioteca está vacía.</strong><span>Marca una canción con ♥ para guardarla aquí.</span></div>';
        return;
    }
    renderizarCanciones(lista, refs.listaBiblioteca, { accionesCrud: false });
}

function actualizarFavoritoVisual() {
    const c = catalogoMusica[indiceActual];
    if (!c) return;
    const activo = favoritos().includes(Number(c.id));
    [refs.btnLike].forEach(btn => {
        if (!btn) return;
        btn.classList.toggle('favorito', activo);
        const i = btn.querySelector('i');
        if (i) i.className = activo ? 'fas fa-heart' : 'far fa-heart';
    });
}

function inicializarPlaylists() {
    let listas = obtenerPlaylists();
    if (!listas.some(p => p.id === 'favoritas')) {
        listas.unshift({ id: 'favoritas', nombre: 'Favoritas', icono: '💜', descripcion: 'Tus canciones guardadas', canciones: [] });
        guardarPlaylists(listas);
    }
}

function obtenerPlaylists() {
    try { return JSON.parse(localStorage.getItem('soundflow_playlists') || '[]'); }
    catch { return []; }
}

function guardarPlaylists(playlists) {
    localStorage.setItem('soundflow_playlists', JSON.stringify(playlists));
}

function mostrarListaPlaylists() {
    renderizarPlaylists();

    if (refs.playlistInicio) refs.playlistInicio.hidden = false;
    if (refs.playlistCrearPanel) refs.playlistCrearPanel.hidden = true;

    if (refs.detallePlaylist) {
        refs.detallePlaylist.hidden = true;
        refs.detallePlaylist.innerHTML = '';
    }

    if (refs.playlistPasoCrear) refs.playlistPasoCrear.hidden = false;
    if (refs.playlistEditor) refs.playlistEditor.innerHTML = '';
    if (refs.nombrePlaylist) refs.nombrePlaylist.value = '';

    mostrarMensajePlaylist('');
}

function mostrarCreadorPlaylist() {
    if (refs.playlistInicio) refs.playlistInicio.hidden = true;

    if (refs.detallePlaylist) {
        refs.detallePlaylist.hidden = true;
        refs.detallePlaylist.innerHTML = '';
    }

    if (refs.playlistCrearPanel) refs.playlistCrearPanel.hidden = false;
    if (refs.playlistPasoCrear) refs.playlistPasoCrear.hidden = false;
    if (refs.playlistEditor) refs.playlistEditor.innerHTML = '';

    mostrarMensajePlaylist('');
    setTimeout(() => refs.nombrePlaylist?.focus(), 50);
}

function crearPlaylist() {
    const nombre = refs.nombrePlaylist?.value.trim();

    if (!nombre) {
        mostrarMensajePlaylist('Escribe un nombre para la playlist.', 'error');
        return;
    }

    const playlists = obtenerPlaylists();

    if (playlists.some(p => p.nombre.toLowerCase() === nombre.toLowerCase())) {
        mostrarMensajePlaylist('Ya existe una playlist con ese nombre.', 'error');
        return;
    }

    const nueva = {
        id: `pl_${Date.now()}`,
        nombre,
        icono: '🎵',
        descripcion: 'Playlist creada por el usuario',
        canciones: []
    };

    playlists.push(nueva);
    guardarPlaylists(playlists);
    renderizarPlaylists();

    if (refs.nombrePlaylist) refs.nombrePlaylist.value = '';

    abrirEditorPlaylist(nueva.id);
}

function mostrarMensajePlaylist(texto, tipo = '') {
    if (!refs.mensajePlaylist) return;

    refs.mensajePlaylist.textContent = texto;
    refs.mensajePlaylist.className = `mensaje-playlist ${tipo ? 'mensaje-' + tipo : ''}`;
}

function renderizarPlaylists() {
    if (!refs.listaPlaylists) return;

    const playlists = obtenerPlaylists();

    if (!playlists.length) {
        refs.listaPlaylists.innerHTML = '<div class="sin-resultados"><strong>No hay playlists todavía.</strong></div>';
        return;
    }

    refs.listaPlaylists.innerHTML = playlists.map(p => {
        const cantidad = p.id === 'favoritas'
            ? favoritos().length
            : (p.canciones || []).length;

        return `<button class="playlist-card" data-playlist-id="${escaparAtributo(p.id)}">
            <span class="playlist-icono">${p.icono || '🎵'}</span>
            <strong>${escaparHtml(p.nombre)}</strong>
            <span>${cantidad} canción(es)</span>
        </button>`;
    }).join('');
}

async function abrirPlaylist(id) {
    const p = obtenerPlaylists().find(item => item.id === id);
    if (!p || !refs.detallePlaylist) return;

    if (refs.playlistInicio) refs.playlistInicio.hidden = true;
    if (refs.playlistCrearPanel) refs.playlistCrearPanel.hidden = true;

    refs.detallePlaylist.hidden = false;
    refs.detallePlaylist.innerHTML = estadoCarga(`Abriendo ${p.nombre}...`);

    const ids = id === 'favoritas'
        ? favoritos()
        : (p.canciones || []).map(Number);

    const canciones = await obtenerCancionesPorIds(ids);

    refs.detallePlaylist.innerHTML = `
        <button class="btn-volver-playlists btn-volver-simple" type="button">
            <i class="fas fa-arrow-left"></i> Volver a playlists
        </button>

        <div class="playlist-detalle-header playlist-detalle-escucha">
            <div>
                <span class="playlist-detalle-icono">${p.icono || '🎵'}</span>
                <div>
                    <h3>${escaparHtml(p.nombre)}</h3>
                    <p>${canciones.length} canción(es)</p>
                </div>
            </div>
        </div>

        <div class="cards-grid" id="playlistCanciones"></div>`;

    const contenedor = $('playlistCanciones');

    if (!canciones.length) {
        contenedor.innerHTML = `
            <div class="sin-resultados">
                <strong>Esta playlist todavía no tiene canciones.</strong>
                <span>Crea una nueva playlist para agregar canciones.</span>
            </div>`;
        return;
    }

    renderizarCanciones(canciones, contenedor, { accionesCrud: false });
}

async function abrirEditorPlaylist(id) {
    const p = obtenerPlaylists().find(item => item.id === id);

    if (!p || p.id === 'favoritas' || !refs.playlistEditor) return;

    if (refs.playlistInicio) refs.playlistInicio.hidden = true;

    if (refs.detallePlaylist) {
        refs.detallePlaylist.hidden = true;
        refs.detallePlaylist.innerHTML = '';
    }

    if (refs.playlistCrearPanel) refs.playlistCrearPanel.hidden = false;
    if (refs.playlistPasoCrear) refs.playlistPasoCrear.hidden = true;

    const ids = (p.canciones || []).map(Number);
    const canciones = await obtenerCancionesPorIds(ids);

    refs.playlistEditor.innerHTML = `
        <div class="playlist-editor-cabecera">
            <div>
                <span class="playlist-editor-etiqueta">Agregando canciones a</span>
                <h3>${p.icono || '🎵'} ${escaparHtml(p.nombre)}</h3>
            </div>

            <button class="btn-mini btn-peligro"
                    id="btnEliminarPlaylist"
                    data-playlist-id="${escaparAtributo(id)}">
                <i class="fas fa-trash"></i> Eliminar
            </button>
        </div>

        <div class="playlist-tools playlist-tools-buscador">
            <div class="playlist-search">
                <i class="fas fa-search"></i>
                <input id="buscarCancionPlaylist"
                       data-playlist-id="${escaparAtributo(id)}"
                       type="text"
                       placeholder="Buscar canción o artista para agregar..."
                       autocomplete="off">
            </div>
        </div>

        <div id="resultadosAgregarPlaylist" class="playlist-resultados-agregar"></div>

        <div class="playlist-editor-actuales">
            <h4>Canciones agregadas</h4>
            <div class="cards-grid" id="playlistCancionesEditor"></div>
        </div>`;

    const actuales = $('playlistCancionesEditor');

    if (canciones.length) {
        renderizarCanciones(
            canciones,
            actuales,
            { accionesCrud: false, playlistId: id }
        );
    } else {
        actuales.innerHTML =
            '<div class="playlist-sin-coincidencias">Todavía no agregaste canciones.</div>';
    }

    renderizarResultadosPlaylistAgregar(id, catalogoMusica);
    setTimeout(() => $('buscarCancionPlaylist')?.focus(), 50);
}

async function obtenerCancionesPorIds(ids) {
    const unicos = [...new Set((ids || []).map(Number).filter(Boolean))];
    const canciones = [];
    for (const id of unicos) {
        let cancion = encontrarCancion(id);
        if (!cancion) {
            try {
                const json = await solicitarJson(`${API_URL}?id=${id}`);
                cancion = json.data || null;
                if (cancion && !catalogoMusica.some(c => Number(c.id) === Number(cancion.id))) catalogoMusica.push(cancion);
            } catch (error) {
                console.error('No se pudo recuperar la canción', id, error);
            }
        }
        if (cancion) canciones.push(cancion);
    }
    return canciones;
}

async function buscarCancionesParaPlaylist(playlistId, texto) {
    const contenedor = $('resultadosAgregarPlaylist');
    if (!contenedor) return;
    if (!texto) {
        renderizarResultadosPlaylistAgregar(playlistId, catalogoMusica);
        return;
    }
    contenedor.innerHTML = estadoCarga('Buscando canciones...');
    try {
        const params = new URLSearchParams({ page: 1, search: texto });
        const json = await solicitarJson(`${API_URL}?${params.toString()}`);
        renderizarResultadosPlaylistAgregar(playlistId, json.data || []);
    } catch (error) {
        contenedor.innerHTML = `<div class="sin-resultados"><strong>No se pudo buscar.</strong><span>${escaparHtml(error.message)}</span></div>`;
    }
}

function renderizarResultadosPlaylistAgregar(playlistId, lista) {
    const contenedor = $('resultadosAgregarPlaylist');
    if (!contenedor) return;
    const p = obtenerPlaylists().find(item => item.id === playlistId);
    if (!p) return;
    const yaAgregadas = new Set((p.canciones || []).map(Number));
    const disponibles = (lista || []).filter(c => !yaAgregadas.has(Number(c.id))).slice(0, 12);
    if (!disponibles.length) {
        contenedor.innerHTML = '<div class="playlist-sin-coincidencias">No hay canciones disponibles con esa búsqueda.</div>';
        return;
    }
    contenedor.innerHTML = `
        <div class="playlist-resultados-titulo">Canciones disponibles</div>
        <div class="playlist-resultados-lista">
            ${disponibles.map((c, i) => `
                <div class="playlist-resultado-item">
                    <img src="${escaparAtributo(c.imagen_url || imagenLocal(i))}" alt="" onerror="this.src='${imagenLocal(i)}'">
                    <div class="playlist-resultado-info"><strong>${escaparHtml(c.titulo)}</strong><span>${escaparHtml(c.artista)}</span></div>
                    <button class="btn-mini btn-agregar-playlist-cancion" data-playlist-id="${escaparAtributo(playlistId)}" data-id="${Number(c.id)}"><i class="fas fa-plus"></i> Agregar</button>
                </div>`).join('')}
        </div>`;
}

function agregarCancionAPlaylist(playlistId, cancionId) {
    if (!cancionId) return;
    const playlists = obtenerPlaylists();
    const p = playlists.find(item => item.id === playlistId);
    if (!p || p.id === 'favoritas') return;
    p.canciones = [...new Set([...(p.canciones || []).map(Number), Number(cancionId)])];
    guardarPlaylists(playlists);
    renderizarPlaylists();
    abrirEditorPlaylist(playlistId);
}

function quitarCancionDePlaylist(playlistId, cancionId) {
    const playlists = obtenerPlaylists();
    const p = playlists.find(item => item.id === playlistId);
    if (!p || p.id === 'favoritas') return;
    p.canciones = (p.canciones || []).map(Number).filter(id => id !== Number(cancionId));
    guardarPlaylists(playlists);
    renderizarPlaylists();
    abrirEditorPlaylist(playlistId);
}

function quitarCancionDeTodasLasPlaylists(cancionId) {
    const playlists = obtenerPlaylists().map(p => ({
        ...p,
        canciones: p.id === 'favoritas' ? (p.canciones || []) : (p.canciones || []).map(Number).filter(id => id !== Number(cancionId))
    }));
    guardarPlaylists(playlists);
}

function eliminarPlaylist(playlistId) {
    if (playlistId === 'favoritas') return;

    const p = obtenerPlaylists().find(item => item.id === playlistId);
    if (!p) return;

    if (!confirm(`¿Eliminar la playlist "${p.nombre}"?`)) return;

    guardarPlaylists(
        obtenerPlaylists().filter(item => item.id !== playlistId)
    );

    mostrarListaPlaylists();
}

function renderizarArtistas() {
    if (!refs.listaArtistas) return;
    const mapa = new Map();

    catalogoMusica.forEach((c, i) => {
        const nombres = String(c.artista || 'Artista desconocido').split(',').map(x => x.trim()).filter(Boolean);
        nombres.forEach(nombre => {
            const clave = nombre.toLowerCase();
            if (!mapa.has(clave)) {
                mapa.set(clave, { nombre, imagen: c.imagen_url || imagenLocal(i), cantidad: 0 });
            }
            mapa.get(clave).cantidad += 1;
        });
    });

    const artistas = [...mapa.values()].sort((a, b) => a.nombre.localeCompare(b.nombre));
    if (!artistas.length) {
        refs.listaArtistas.innerHTML = '<div class="sin-resultados"><strong>No hay artistas para mostrar.</strong></div>';
        return;
    }

    refs.listaArtistas.innerHTML = artistas.map(a => `
        <button class="card artista-card-btn" data-artista="${escaparAtributo(a.nombre)}">
            <div class="card-image artist-card"><img src="${escaparAtributo(a.imagen)}" alt="${escaparAtributo(a.nombre)}" onerror="this.src='img/playlist/1.jpg'"></div>
            <div class="card-info"><h3>${escaparHtml(a.nombre)}</h3><p>${a.cantidad} canción(es) en el catálogo actual</p><small>Ver canciones</small></div>
        </button>`).join('');
}

async function abrirArtista(nombre) {
    if (!refs.detalleArtista) return;
    refs.detalleArtista.innerHTML = estadoCarga(`Buscando canciones de ${nombre}...`);

    try {
        const params = new URLSearchParams({ page: 1, search: nombre });
        const json = await solicitarJson(`${API_URL}?${params.toString()}`);
        const canciones = (json.data || []).filter(c => String(c.artista || '').toLowerCase().includes(nombre.toLowerCase()));
        refs.detalleArtista.innerHTML = `
            <div class="artista-detalle-header"><h3>${escaparHtml(nombre)}</h3><p>Canciones de este artista</p></div>
            <div class="cards-grid" id="artistaCanciones"></div>`;
        renderizarCanciones(canciones, $('artistaCanciones'), { accionesCrud: false });
        refs.detalleArtista.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } catch (error) {
        refs.detalleArtista.innerHTML = `<div class="sin-resultados"><strong>No se pudieron cargar las canciones.</strong><span>${escaparHtml(error.message)}</span></div>`;
    }
}

function encontrarCancion(id) {
    return catalogoMusica.find(c => Number(c.id) === Number(id)) || resultadosBusqueda.find(c => Number(c.id) === Number(id));
}

async function reproducirPorId(id) {
    let indice = catalogoMusica.findIndex(c => Number(c.id) === Number(id));
    if (indice < 0) {
        try {
            const json = await solicitarJson(`${API_URL}?id=${Number(id)}`);
            if (json.data) {
                catalogoMusica.push(json.data);
                indice = catalogoMusica.length - 1;
            }
        } catch (error) {
            console.error(error);
            return;
        }
    }
    indiceActual = indice;
    cargarCancion(indice);
    reproducirCancion();
}

function cargarCancion(indice) {
    const c = catalogoMusica[indice];
    if (!c) return;

    indiceActual = indice;
    usandoAudioRespaldo = false;

    const rutaAudio = (c.audio_url || '').trim();
    audio.src = rutaAudio || audioRespaldo(indice);
    audio.load();

    if (refs.playerTitulo) refs.playerTitulo.textContent = c.titulo;
    if (refs.playerArtista) refs.playerArtista.textContent = c.artista;

    if (refs.playerImagen) {
        refs.playerImagen.src = c.imagen_url || imagenLocal(indice);
        refs.playerImagen.onerror = () => {
            refs.playerImagen.src = imagenLocal(indice);
        };
    }

    if (refs.barraProgreso) refs.barraProgreso.value = 0;
    if (refs.tiempoActual) refs.tiempoActual.textContent = '0:00';
    if (refs.duracionTotal) refs.duracionTotal.textContent = c.duracion || '0:00';

    reproduciendo = false;
    if (refs.btnPlayer) {
        refs.btnPlayer.innerHTML = '<i class="fas fa-play"></i>';
        refs.btnPlayer.title = 'Reproducir';
    }

    actualizarFavoritoVisual();
}

async function reproducirCancion() {
    if (!catalogoMusica.length) return;

    if (!audio.src) {
        cargarCancion(indiceActual);
    }

    try {
        await audio.play();
        reproduciendo = true;

        if (refs.btnPlayer) {
            refs.btnPlayer.innerHTML = '<i class="fas fa-pause"></i>';
            refs.btnPlayer.title = 'Pausar';
        }

    } catch (error) {
        console.warn('No se pudo reproducir el archivo indicado por la base de datos:', error);

        // Si el MP3 guardado en MySQL ya no está físicamente en audio/uploads,
        // usa uno de los MP3 de demostración para que el reproductor siga funcionando.
        if (!usandoAudioRespaldo) {
            usandoAudioRespaldo = true;
            audio.src = audioRespaldo(indiceActual);
            audio.load();

            try {
                await audio.play();
                reproduciendo = true;

                if (refs.btnPlayer) {
                    refs.btnPlayer.innerHTML = '<i class="fas fa-pause"></i>';
                    refs.btnPlayer.title = 'Pausar';
                }
                return;
            } catch (segundoError) {
                console.error('Tampoco se pudo reproducir el audio de respaldo:', segundoError);
            }
        }

        reproduciendo = false;

        if (refs.btnPlayer) {
            refs.btnPlayer.innerHTML = '<i class="fas fa-play"></i>';
            refs.btnPlayer.title = 'Reproducir';
        }
    }
}

function pausarCancion() {
    audio.pause();
    reproduciendo = false;

    if (refs.btnPlayer) {
        refs.btnPlayer.innerHTML = '<i class="fas fa-play"></i>';
        refs.btnPlayer.title = 'Reproducir';
    }
}

function siguienteCancion() {
    if (!catalogoMusica.length) return;
    indiceActual = (indiceActual + 1) % catalogoMusica.length;
    cargarCancion(indiceActual);
    reproducirCancion();
}

function anteriorCancion() {
    if (!catalogoMusica.length) return;
    indiceActual = (indiceActual - 1 + catalogoMusica.length) % catalogoMusica.length;
    cargarCancion(indiceActual);
    reproducirCancion();
}

function actualizarProgreso() {
    if (!audio.duration) return;
    if (refs.barraProgreso) refs.barraProgreso.value = (audio.currentTime / audio.duration) * 100;
    if (refs.tiempoActual) refs.tiempoActual.textContent = formatearTiempo(audio.currentTime);
    if (refs.duracionTotal) refs.duracionTotal.textContent = formatearTiempo(audio.duration);
}

function formatearTiempo(segundos) {
    if (!Number.isFinite(segundos)) return '0:00';
    const m = Math.floor(segundos / 60);
    const s = Math.floor(segundos % 60);
    return `${m}:${String(s).padStart(2, '0')}`;
}

function estadoCarga(texto) {
    return `<div class="estado-carga"><i class="fas fa-circle-notch fa-spin"></i> ${escaparHtml(texto)}</div>`;
}

function audioRespaldo(i) {
    return `audio/cancion${(Number(i) % 3) + 1}.mp3`;
}

function imagenLocal(i) { return `img/songs/${(i % 8) + 1}.jpg`; }
function escaparHtml(texto) { const div = document.createElement('div'); div.textContent = texto ?? ''; return div.innerHTML; }
function escaparAtributo(texto) { return escaparHtml(String(texto ?? '')).replace(/"/g, '&quot;'); }
