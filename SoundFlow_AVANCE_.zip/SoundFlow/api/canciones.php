<?php

header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

require_once __DIR__ . '/../config.php';

$metodo = $_SERVER['REQUEST_METHOD'];
if ($metodo === 'OPTIONS') {
    http_response_code(204);
    exit;
}

try {
    switch ($metodo) {
        case 'GET': manejarGet($pdo); break;
        case 'POST': manejarPost($pdo); break;
        case 'PUT': manejarPut($pdo); break;
        case 'DELETE': manejarDelete($pdo); break;
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'error' => 'Método HTTP no permitido.'], JSON_UNESCAPED_UNICODE);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Error de base de datos.', 'detail' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
}

function manejarGet(PDO $pdo): void
{
    if (isset($_GET['id'])) {
        $stmt = $pdo->prepare('SELECT * FROM canciones WHERE id = :id');
        $stmt->execute([':id' => (int)$_GET['id']]);
        $cancion = $stmt->fetch();
        if (!$cancion) {
            http_response_code(404);
            echo json_encode(['success' => false, 'error' => 'Canción no encontrada.'], JSON_UNESCAPED_UNICODE);
            return;
        }
        echo json_encode(['success' => true, 'data' => $cancion], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return;
    }

    $busqueda = trim((string)($_GET['search'] ?? ''));
    $pagina = max(1, (int)($_GET['page'] ?? 1));
    $porPagina = 12;
    $offset = ($pagina - 1) * $porPagina;

    $where = '';
    $params = [];
    if ($busqueda !== '') {
        $where = ' WHERE titulo LIKE :q_titulo OR artista LIKE :q_artista OR album LIKE :q_album OR genero LIKE :q_genero ';
        $textoBusqueda = "%{$busqueda}%";
        $params = [
            ':q_titulo' => $textoBusqueda,
            ':q_artista' => $textoBusqueda,
            ':q_album' => $textoBusqueda,
            ':q_genero' => $textoBusqueda,
        ];
    }

    $stmtTotal = $pdo->prepare('SELECT COUNT(*) FROM canciones' . $where);
    foreach ($params as $clave => $valor) {
        $stmtTotal->bindValue($clave, $valor);
    }
    $stmtTotal->execute();
    $total = (int)$stmtTotal->fetchColumn();

    $stmt = $pdo->prepare('SELECT * FROM canciones' . $where . ' ORDER BY id DESC LIMIT :limite OFFSET :offset');
    foreach ($params as $clave => $valor) {
        $stmt->bindValue($clave, $valor);
    }
    $stmt->bindValue(':limite', $porPagina, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();

    echo json_encode([
        'success' => true,
        'data' => $stmt->fetchAll(),
        'meta' => [
            'page' => $pagina,
            'per_page' => $porPagina,
            'total' => $total,
            'pages' => max(1, (int)ceil($total / $porPagina)),
        ],
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function leerJson(): array
{
    $input = json_decode(file_get_contents('php://input'), true);
    return is_array($input) ? $input : [];
}

function validar(array $input, bool $requiereId = false): array
{
    $errores = [];
    if ($requiereId && empty($input['id'])) $errores[] = 'El id es obligatorio.';
    if (mb_strlen(trim((string)($input['titulo'] ?? ''))) < 2) $errores[] = 'El título debe tener al menos 2 caracteres.';
    if (mb_strlen(trim((string)($input['artista'] ?? ''))) < 2) $errores[] = 'El artista debe tener al menos 2 caracteres.';
    return $errores;
}

function manejarPost(PDO $pdo): void
{

    $input = $_POST;
    $errores = validar($input);

    if (!isset($_FILES['audio'])) {
        $errores[] = 'Debes seleccionar un archivo MP3.';
    }

    if ($errores) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => 'Datos inválidos.',
            'errors' => $errores
        ], JSON_UNESCAPED_UNICODE);
        return;
    }

    $audio = $_FILES['audio'];

    if ($audio['error'] !== UPLOAD_ERR_OK) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => 'No se pudo subir el archivo MP3.',
            'detail' => 'Código de subida: ' . $audio['error']
        ], JSON_UNESCAPED_UNICODE);
        return;
    }

    $maxBytes = 25 * 1024 * 1024;

    if ((int)$audio['size'] > $maxBytes) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => 'El MP3 supera el límite de 25 MB.'
        ], JSON_UNESCAPED_UNICODE);
        return;
    }

    $extension = strtolower(pathinfo($audio['name'], PATHINFO_EXTENSION));

    if ($extension !== 'mp3') {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error' => 'Solo se permiten archivos .mp3.'
        ], JSON_UNESCAPED_UNICODE);
        return;
    }

    $directorioFisico = __DIR__ . '/../audio/uploads';

    if (!is_dir($directorioFisico) && !mkdir($directorioFisico, 0775, true)) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => 'No se pudo crear la carpeta audio/uploads.'
        ], JSON_UNESCAPED_UNICODE);
        return;
    }

    $nombreSeguro = 'song_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.mp3';
    $destinoFisico = $directorioFisico . '/' . $nombreSeguro;
    $rutaWeb = 'audio/uploads/' . $nombreSeguro;

    if (!move_uploaded_file($audio['tmp_name'], $destinoFisico)) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => 'El servidor no pudo guardar el archivo MP3.'
        ], JSON_UNESCAPED_UNICODE);
        return;
    }

    try {
        $sql = 'INSERT INTO canciones
            (external_id, titulo, artista, album, genero, duracion, imagen_url, audio_url, store_url, fuente)
            VALUES
            (:external_id, :titulo, :artista, :album, :genero, :duracion, :imagen_url, :audio_url, :store_url, :fuente)';

        $stmt = $pdo->prepare($sql);

        $stmt->execute([
            ':external_id' => uniqid('local_'),
            ':titulo' => trim((string)$input['titulo']),
            ':artista' => trim((string)$input['artista']),
            ':album' => trim((string)($input['album'] ?? '')),
            ':genero' => trim((string)($input['genero'] ?? '')),
            ':duracion' => trim((string)($input['duracion'] ?? '0:00')),
            ':imagen_url' => trim((string)($input['imagen_url'] ?? 'img/songs/1.jpg')) ?: 'img/songs/1.jpg',
            ':audio_url' => $rutaWeb,
            ':store_url' => '',
            ':fuente' => 'usuario'
        ]);

        $id = (int)$pdo->lastInsertId();

        http_response_code(201);

        echo json_encode([
            'success' => true,
            'id' => $id,
            'audio_url' => $rutaWeb,
            'message' => 'Canción y MP3 guardados correctamente.'
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    } catch (Throwable $e) {
        if (is_file($destinoFisico)) {
            @unlink($destinoFisico);
        }
        throw $e;
    }
}

function manejarPut(PDO $pdo): void
{
    $input = leerJson();
    $errores = validar($input, true);
    if ($errores) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Datos inválidos.', 'errors' => $errores], JSON_UNESCAPED_UNICODE);
        return;
    }

    $sql = 'UPDATE canciones SET titulo=:titulo, artista=:artista, album=:album, genero=:genero,
            duracion=:duracion, imagen_url=:imagen_url, audio_url=:audio_url WHERE id=:id';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':id' => (int)$input['id'],
        ':titulo' => trim((string)$input['titulo']),
        ':artista' => trim((string)$input['artista']),
        ':album' => trim((string)($input['album'] ?? '')),
        ':genero' => trim((string)($input['genero'] ?? '')),
        ':duracion' => trim((string)($input['duracion'] ?? '0:00')),
        ':imagen_url' => trim((string)($input['imagen_url'] ?? 'img/songs/1.jpg')) ?: 'img/songs/1.jpg',
        ':audio_url' => trim((string)($input['audio_url'] ?? 'audio/cancion1.mp3')) ?: 'audio/cancion1.mp3',
    ]);

    echo json_encode(['success' => true, 'affected' => $stmt->rowCount(), 'message' => 'Canción actualizada.'], JSON_UNESCAPED_UNICODE);
}

function manejarDelete(PDO $pdo): void
{
    $id = (int)($_GET['id'] ?? 0);
    if ($id <= 0) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Se requiere un id válido.'], JSON_UNESCAPED_UNICODE);
        return;
    }
    $stmt = $pdo->prepare('DELETE FROM canciones WHERE id = :id');
    $stmt->execute([':id' => $id]);
    echo json_encode(['success' => true, 'deleted' => $stmt->rowCount()], JSON_UNESCAPED_UNICODE);
}
