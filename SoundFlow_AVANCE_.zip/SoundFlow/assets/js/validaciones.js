function limpiarTexto(valor) {
    return String(valor ?? '').trim().replace(/\s+/g, ' ');
}

function validarCancion(datos) {
    const titulo = limpiarTexto(datos.titulo);
    const artista = limpiarTexto(datos.artista);
    const album = limpiarTexto(datos.album);
    const errores = [];

    if (titulo.length < 2) errores.push('El título debe tener al menos 2 caracteres.');
    if (titulo.length > 150) errores.push('El título no puede superar 150 caracteres.');
    if (artista.length < 2) errores.push('El artista debe tener al menos 2 caracteres.');
    if (artista.length > 150) errores.push('El artista no puede superar 150 caracteres.');
    if (album.length > 150) errores.push('El álbum no puede superar 150 caracteres.');

    return {
        esValido: errores.length === 0,
        errores,
        datosLimpios: { titulo, artista, album }
    };
}
