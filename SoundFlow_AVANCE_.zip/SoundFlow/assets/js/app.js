const API_URL = 'api/canciones.php';
let paginaActual = 1;
let catalogoMusica = [];
let resultadosBusqueda = [];
let indiceActual = 0;
let reproduciendo = false;
let modoAleatorio = false;
let modoRepetir = false;
let vistaActual = 'inicio';
const audio = new Audio();
audio.volume = 0.7;

const $ = (id) => document.getElementById(id);
const refs = {};

const nombresVistas = {
    inicio: 'Inicio',
    buscar: 'Buscar',
    musica: 'Música',
    biblioteca: 'Biblioteca',
    playlists: 'Playlists',
    artistas: 'Artistas',
    agregar: 'Agregar canción',
};

document.addEventListener('DOMContentLoaded', () => {
    Object.assign(refs, {
        menu: $('menuPrincipal'), tituloVista: $('tituloVistaActual'),
        listaInicio: $('listaInicio'), lista: $('listaCanciones'), paginacion: $('paginacion'),
        resultadosBusqueda: $('resultadosBusqueda'), textoBusqueda: $('textoBusqueda'), buscador: $('buscador'),
        listaBiblioteca: $('listaBiblioteca'), listaPlaylists: $('listaPlaylists'), detallePlaylist: $('detallePlaylist'),
        form: $('formCancion'), cancionId: $('cancionId'), titulo: $('titulo'), artista: $('artista'), album: $('album'),
        genero: $('genero'), imagenUrl: $('imagenUrl'), audioArchivo: $('audioArchivo'), mensaje: $('mensajeFormulario'),
        tituloFormulario: $('tituloFormulario'), btnGuardar: $('btnGuardarCancion'), btnCancelar: $('btnCancelarEdicion'),
        btnRecargar: $('btnRecargar'), btnPlayDestacado: $('btnPlayDestacado'), btnFavorito: $('btnFavorito'),
        playerTitulo: $('playerTitulo'), playerArtista: $('playerArtista'), playerImagen: $('playerImagen'),
        btnPlayer: $('btnPlayer'), btnAnterior: $('btnAnterior'), btnSiguiente: $('btnSiguiente'), btnShuffle: $('btnShuffle'),
        btnRepeat: $('btnRepeat'), btnLike: $('btnLike'), barraProgreso: $('barraProgreso'), controlVolumen: $('controlVolumen'),
        tiempoActual: $('tiempoActual'), duracionTotal: $('duracionTotal'),
    });

    instalarEventos();
    inicializarPlaylists();
    cargarCanciones();
    mostrarVista('inicio');
});

function instalarEventos() {
    refs.menu?.addEventListener('click', (e) => {
        const boton = e.target.closest('[data-view]');
        if (!boton) return;
        mostrarVista(boton.dataset.view);
    });

    refs.btnRecargar?.addEventListener('click', () => cargarCanciones());

    refs.buscador?.addEventListener('input', (e) => buscarCanciones(e.target.value.trim()));

    refs.form?.addEventListener('submit', guardarCancion);
    refs.btnCancelar?.addEventListener('click', () => prepararNueva(false));

    document.querySelector('.main-content')?.addEventListener('click', (e) => {
        const play = e.target.closest('.play-button');
        const editar = e.target.closest('.btn-editar');
        const eliminar = e.target.closest('.btn-eliminar');
        const favorito = e.target.closest('.btn-favorito-card');
        const playlist = e.target.closest('[data-playlist-id]');

        if (play) reproducirPorId(Number(play.dataset.id));
        if (editar) editarCancion(Number(editar.dataset.id));
        if (eliminar) eliminarCancion(Number(eliminar.dataset.id));
        if (favorito) toggleFavorito(Number(favorito.dataset.id));
        if (playlist) abrirPlaylist(playlist.dataset.playlistId);
    });

    refs.btnPlayer?.addEventListener('click', () => reproduciendo ? pausarCancion() : reproducirCancion());
    refs.btnSiguiente?.addEventListener('click', siguienteCancion);
    refs.btnAnterior?.addEventListener('click', anteriorCancion);
    refs.btnShuffle?.addEventListener('click', () => {
        modoAleatorio = !modoAleatorio;
        refs.btnShuffle.classList.toggle('activo', modoAleatorio);
    });
    refs.btnRepeat?.addEventListener('click', () => {
        modoRepetir = !modoRepetir;
        audio.loop = modoRepetir;
        refs.btnRepeat.classList.toggle('activo', modoRepetir);
    });
    refs.btnPlayDestacado?.addEventListener('click', () => {
        if (!catalogoMusica.length) return;
        indiceActual = 0;
        cargarCancion(0);
        reproducirCancion();
    });
    refs.btnLike?.addEventListener('click', () => toggleFavoritoActual());
    refs.btnFavorito?.addEventListener('click', () => toggleFavoritoActual());

    refs.barraProgreso?.addEventListener('input', () => {
        if (audio.duration) audio.currentTime = (Number(refs.barraProgreso.value) / 100) * audio.duration;
    });
    refs.controlVolumen?.addEventListener('input', () => audio.volume = Number(refs.controlVolumen.value));

    audio.addEventListener('timeupdate', actualizarProgreso);
    audio.addEventListener('ended', () => { if (!modoRepetir) siguienteCancion(); });
}

function mostrarVista(nombre) {
    vistaActual = nombre;
    document.querySelectorAll('.vista').forEach(v => v.classList.remove('activa'));
    $(`vista-${nombre}`)?.classList.add('activa');
    refs.menu?.querySelectorAll('[data-view]').forEach(b => b.classList.toggle('active', b.dataset.view === nombre));
    if (refs.tituloVista) refs.tituloVista.textContent = nombresVistas[nombre] || 'SoundFlow';

    if (nombre === 'biblioteca') renderizarBiblioteca();
    if (nombre === 'playlists') renderizarPlaylists();
    if (nombre === 'agregar' && !refs.cancionId.value) prepararNueva(false);
    if (nombre === 'buscar') setTimeout(() => refs.buscador?.focus(), 50);

    window.scrollTo({ top: 0, behavior: 'smooth' });
}

async function solicitarJson(url, opciones = {}) {
    const respuesta = await fetch(url, opciones);
    let json;
    try {
        json = await respuesta.json();
    } catch {
        throw new Error(`El servidor respondió HTTP ${respuesta.status}, pero no devolvió JSON válido.`);
    }
    if (!respuesta.ok || json.success === false) {
        const detalle = Array.isArray(json.errors) ? json.errors.join(' ') : '';
        throw new Error(json.error || detalle || `Error HTTP ${respuesta.status}`);
    }
    return json;
}

async function cargarCanciones() {
    refs.lista.innerHTML = estadoCarga('Consultando catálogo...');
    refs.listaInicio.innerHTML = estadoCarga('Cargando música...');

    const params = new URLSearchParams({ page: paginaActual, search: '' });
    try {
        const json = await solicitarJson(`${API_URL}?${params.toString()}`);
        catalogoMusica = json.data || [];
        renderizarCanciones(catalogoMusica, refs.lista, { accionesCrud: true });
        renderizarCanciones(catalogoMusica.slice(0, 4), refs.listaInicio, { accionesCrud: false });
        renderizarPaginacion(json.meta || { page: 1, pages: 1, total: catalogoMusica.length });

        if (catalogoMusica.length && !audio.src) cargarCancion(0);
        renderizarBiblioteca();
        renderizarPlaylists();
    } catch (error) {
        console.error('[cargarCanciones]', error);
        const html = `<div class="sin-resultados"><i class="fas fa-triangle-exclamation"></i><strong>No se pudo conectar con la API.</strong><span>${escaparHtml(error.message)}</span></div>`;
        refs.lista.innerHTML = html;
        refs.listaInicio.innerHTML = html;
        renderizarPaginacion({ pages: 1 });

    }
}

async function buscarCanciones(texto) {
    if (!texto) {
        resultadosBusqueda = [];
        refs.resultadosBusqueda.innerHTML = '';
        refs.textoBusqueda.textContent = 'Escribe algo para comenzar.';
        return;
    }

    refs.textoBusqueda.textContent = `Buscando “${texto}”...`;
    refs.resultadosBusqueda.innerHTML = estadoCarga('Buscando...');

    try {
        const params = new URLSearchParams({ page: 1, search: texto });
        const json = await solicitarJson(`${API_URL}?${params.toString()}`);
        resultadosBusqueda = json.data || [];
        refs.textoBusqueda.textContent = `${json.meta?.total ?? resultadosBusqueda.length} resultado(s) para “${texto}”`;
        renderizarCanciones(resultadosBusqueda, refs.resultadosBusqueda, { accionesCrud: false });
    } catch (error) {
        refs.resultadosBusqueda.innerHTML = `<div class="sin-resultados"><strong>Error al buscar.</strong><span>${escaparHtml(error.message)}</span></div>`;
    }
}

function renderizarCanciones(lista, contenedor, opciones = {}) {
    if (!contenedor) return;
    if (!lista.length) {
        contenedor.innerHTML = '<div class="sin-resultados"><i class="fas fa-music"></i><strong>No se encontraron canciones.</strong></div>';
        return;
    }

    const favoritosIds = favoritos();
    contenedor.innerHTML = lista.map((c, i) => {
        const esFavorita = favoritosIds.includes(Number(c.id));
        return `
        <article class="card" data-id="${Number(c.id)}">
            <div class="card-image">
                <img src="${escaparAtributo(c.imagen_url || imagenLocal(i))}" alt="Portada de ${escaparAtributo(c.titulo)}" onerror="this.src='${imagenLocal(i)}'">
                <button class="play-button" data-id="${Number(c.id)}" title="Reproducir"><i class="fas fa-play"></i></button>
                <button class="btn-favorito-card ${esFavorita ? 'favorito' : ''}" data-id="${Number(c.id)}" title="Guardar en biblioteca"><i class="${esFavorita ? 'fas' : 'far'} fa-heart"></i></button>
            </div>
            <div class="card-info">
                <h3>${escaparHtml(c.titulo)}</h3>
                <p>${escaparHtml(c.artista)}</p>
                <small>${escaparHtml(c.album || 'Sin álbum')} ${c.genero ? '• ' + escaparHtml(c.genero) : ''}</small>
                ${opciones.accionesCrud ? `
                <div class="card-actions">
                    <button class="btn-card btn-editar" data-id="${Number(c.id)}"><i class="fas fa-pen"></i> Editar</button>
                    <button class="btn-card btn-eliminar" data-id="${Number(c.id)}"><i class="fas fa-trash"></i> Eliminar</button>
                </div>` : ''}
            </div>
        </article>`;
    }).join('');
}

function renderizarPaginacion(meta) {
    const paginas = Number(meta.pages || 1);
    if (paginas <= 1) { refs.paginacion.innerHTML = ''; return; }
    let html = `<button ${paginaActual <= 1 ? 'disabled' : ''} data-page="${paginaActual - 1}">‹</button>`;
    for (let p = 1; p <= paginas; p++) {
        if (p === 1 || p === paginas || Math.abs(p - paginaActual) <= 2) {
            html += `<button class="${p === paginaActual ? 'active' : ''}" data-page="${p}">${p}</button>`;
        }
    }
    html += `<button ${paginaActual >= paginas ? 'disabled' : ''} data-page="${paginaActual + 1}">›</button>`;
    refs.paginacion.innerHTML = html;
    refs.paginacion.querySelectorAll('button[data-page]:not([disabled])').forEach(btn => {
        btn.addEventListener('click', () => {
            paginaActual = Number(btn.dataset.page);
            cargarCanciones();
        });
    });
}

async function guardarCancion(e) {
    e.preventDefault();

    const datosBase = {
        titulo: refs.titulo.value,
        artista: refs.artista.value,
        album: refs.album.value
    };

    const validacion = typeof validarCancion === 'function'
        ? validarCancion(datosBase)
        : { esValido: true, errores: [], datosLimpios: datosBase };

    if (!validacion.esValido) {
        mostrarMensaje(validacion.errores.join(' '), 'error');
        return;
    }

    const id = Number(refs.cancionId.value || 0);
    const existente = encontrarCancion(id);

    refs.btnGuardar.disabled = true;
    mostrarMensaje(id ? 'Actualizando...' : 'Subiendo MP3 y guardando...', 'aviso');

    try {
        let json;

        if (!id) {

            const archivo = refs.audioArchivo?.files?.[0];

            if (!archivo) {
                throw new Error('Selecciona un archivo MP3.');
            }

            if (!archivo.name.toLowerCase().endsWith('.mp3')) {
                throw new Error('El archivo debe ser MP3.');
            }

            const formData = new FormData();
            formData.append('titulo', validacion.datosLimpios.titulo);
            formData.append('artista', validacion.datosLimpios.artista);
            formData.append('album', validacion.datosLimpios.album || '');
            formData.append('genero', refs.genero.value.trim());
            formData.append('duracion', '0:00');
            formData.append('imagen_url', refs.imagenUrl.value.trim() || 'img/songs/1.jpg');
            formData.append('audio', archivo);

            json = await solicitarJson(API_URL, {
                method: 'POST',
                headers: { Accept: 'application/json' },
                body: formData
            });

        } else {

            const datos = {
                ...validacion.datosLimpios,
                genero: refs.genero.value.trim(),
                duracion: existente?.duracion || '0:00',
                imagen_url: refs.imagenUrl.value.trim() || 'img/songs/1.jpg',
                audio_url: existente?.audio_url || 'audio/cancion1.mp3',
                id
            };

            json = await solicitarJson(API_URL, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    Accept: 'application/json'
                },
                body: JSON.stringify(datos)
            });
        }

        mostrarMensaje(json.message || 'Canción guardada correctamente.', 'exito');
        prepararNueva(false);
        paginaActual = 1;
        await cargarCanciones();
        mostrarVista('musica');

    } catch (error) {
        mostrarMensaje(error.message, 'error');
    } finally {
        refs.btnGuardar.disabled = false;
    }
}

function editarCancion(id) {
    const c = encontrarCancion(id);
    if (!c) return;
    refs.cancionId.value = c.id;
    refs.titulo.value = c.titulo || '';
    refs.artista.value = c.artista || '';
    refs.album.value = c.album || '';
    refs.genero.value = c.genero || '';
    refs.imagenUrl.value = c.imagen_url || '';
    refs.tituloFormulario.textContent = 'Editar canción';
    refs.btnGuardar.innerHTML = '<i class="fas fa-floppy-disk"></i> ACTUALIZAR CANCIÓN';
    refs.btnCancelar.hidden = false;
    refs.mensaje.textContent = '';
    mostrarVista('agregar');
}

function prepararNueva() {
    refs.form?.reset();
    refs.cancionId.value = '';
    refs.tituloFormulario.textContent = 'Agregar canción';
    refs.btnGuardar.innerHTML = '<i class="fas fa-plus"></i> AGREGAR CANCIÓN';
    refs.btnCancelar.hidden = true;
    refs.mensaje.textContent = '';
}

async function eliminarCancion(id) {
    const c = encontrarCancion(id);
    if (!confirm(`¿Eliminar "${c?.titulo || 'esta canción'}" de MySQL?`)) return;
    try {
        const json = await solicitarJson(`${API_URL}?id=${id}`, { method: 'DELETE' });
        if (!json.deleted) throw new Error('No se eliminó ningún registro.');
        quitarFavoritoSiExiste(id);
        await cargarCanciones();
    } catch (error) {
        alert('Error al eliminar: ' + error.message);
    }
}

function mostrarMensaje(texto, tipo) {
    refs.mensaje.textContent = texto;
    refs.mensaje.className = `mensaje-formulario mensaje-${tipo}`;
}

function favoritos() {
    try { return JSON.parse(localStorage.getItem('soundflow_favoritos') || '[]').map(Number); }
    catch { return []; }
}

function guardarFavoritos(lista) {
    localStorage.setItem('soundflow_favoritos', JSON.stringify([...new Set(lista.map(Number))]));
}

function toggleFavorito(id) {
    const lista = favoritos();
    const pos = lista.indexOf(Number(id));
    if (pos >= 0) lista.splice(pos, 1); else lista.push(Number(id));
    guardarFavoritos(lista);
    renderizarCanciones(catalogoMusica, refs.lista, { accionesCrud: true });
    renderizarCanciones(catalogoMusica.slice(0, 4), refs.listaInicio, { accionesCrud: false });
    if (resultadosBusqueda.length) renderizarCanciones(resultadosBusqueda, refs.resultadosBusqueda, { accionesCrud: false });
    renderizarBiblioteca();
    actualizarFavoritoVisual();
}

function toggleFavoritoActual() {
    const c = catalogoMusica[indiceActual];
    if (c) toggleFavorito(Number(c.id));
}

function quitarFavoritoSiExiste(id) {
    guardarFavoritos(favoritos().filter(x => x !== Number(id)));
}

function renderizarBiblioteca() {
    const ids = favoritos();
    const lista = catalogoMusica.filter(c => ids.includes(Number(c.id)));
    if (!lista.length) {
        refs.listaBiblioteca.innerHTML = '<div class="sin-resultados"><i class="far fa-heart"></i><strong>Tu biblioteca está vacía.</strong><span>Marca una canción con ♥ para guardarla aquí.</span></div>';
        return;
    }
    renderizarCanciones(lista, refs.listaBiblioteca, { accionesCrud: false });
}

function actualizarFavoritoVisual() {
    const c = catalogoMusica[indiceActual];
    if (!c) return;
    const activo = favoritos().includes(Number(c.id));
    [refs.btnLike, refs.btnFavorito].forEach(btn => {
        if (!btn) return;
        btn.classList.toggle('favorito', activo);
        const i = btn.querySelector('i');
        if (i) i.className = activo ? 'fas fa-heart' : 'far fa-heart';
    });
}

function inicializarPlaylists() {
    if (localStorage.getItem('soundflow_playlists')) return;
    const iniciales = [
        { id: 'urbano', nombre: 'Urbano', icono: '🔥', descripcion: 'Trap y reggaetón', canciones: [1, 2, 3] },
        { id: 'favoritas', nombre: 'Favoritas', icono: '💜', descripcion: 'Tus canciones guardadas', canciones: [] },
        { id: 'noche', nombre: 'Noche', icono: '🌙', descripcion: 'Para escuchar de noche', canciones: [1, 3] },
    ];
    localStorage.setItem('soundflow_playlists', JSON.stringify(iniciales));
}

function obtenerPlaylists() {
    try { return JSON.parse(localStorage.getItem('soundflow_playlists') || '[]'); }
    catch { return []; }
}

function renderizarPlaylists() {
    const playlists = obtenerPlaylists();
    refs.listaPlaylists.innerHTML = playlists.map(p => {
        const cantidad = p.id === 'favoritas' ? favoritos().length : p.canciones.length;
        return `<button class="playlist-card" data-playlist-id="${escaparAtributo(p.id)}">
            <span class="playlist-icono">${p.icono}</span>
            <strong>${escaparHtml(p.nombre)}</strong>
            <small>${escaparHtml(p.descripcion)}</small>
            <span>${cantidad} canción(es)</span>
        </button>`;
    }).join('');
}

function abrirPlaylist(id) {
    const p = obtenerPlaylists().find(item => item.id === id);
    if (!p) return;
    const ids = id === 'favoritas' ? favoritos() : p.canciones.map(Number);
    const canciones = catalogoMusica.filter(c => ids.includes(Number(c.id)));
    refs.detallePlaylist.innerHTML = `<div class="playlist-detalle-header"><h3>${p.icono} ${escaparHtml(p.nombre)}</h3><p>${escaparHtml(p.descripcion)}</p></div><div class="cards-grid" id="playlistCanciones"></div>`;
    renderizarCanciones(canciones, $('playlistCanciones'), { accionesCrud: false });
    refs.detallePlaylist.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function encontrarCancion(id) {
    return catalogoMusica.find(c => Number(c.id) === Number(id)) || resultadosBusqueda.find(c => Number(c.id) === Number(id));
}

async function reproducirPorId(id) {
    let indice = catalogoMusica.findIndex(c => Number(c.id) === Number(id));
    if (indice < 0) {
        try {
            const json = await solicitarJson(`${API_URL}?id=${Number(id)}`);
            if (json.data) {
                catalogoMusica.push(json.data);
                indice = catalogoMusica.length - 1;
            }
        } catch (error) {
            console.error(error);
            return;
        }
    }
    indiceActual = indice;
    cargarCancion(indice);
    reproducirCancion();
}

function cargarCancion(indice) {
    const c = catalogoMusica[indice];
    if (!c) return;
    audio.src = c.audio_url || `audio/cancion${(indice % 3) + 1}.mp3`;
    refs.playerTitulo.textContent = c.titulo;
    refs.playerArtista.textContent = c.artista;
    refs.playerImagen.src = c.imagen_url || imagenLocal(indice);
    refs.playerImagen.onerror = () => { refs.playerImagen.src = imagenLocal(indice); };
    refs.barraProgreso.value = 0;
    refs.tiempoActual.textContent = '0:00';
    refs.duracionTotal.textContent = c.duracion || '0:00';
    actualizarFavoritoVisual();
}

async function reproducirCancion() {
    if (!catalogoMusica.length) return;
    if (!audio.src) cargarCancion(indiceActual);
    try {
        await audio.play();
        reproduciendo = true;
        refs.btnPlayer.innerHTML = '<i class="fas fa-pause"></i>';
    } catch (e) {
        console.error('No se pudo reproducir:', e);
    }
}

function pausarCancion() {
    audio.pause();
    reproduciendo = false;
    refs.btnPlayer.innerHTML = '<i class="fas fa-play"></i>';
}

function siguienteCancion() {
    if (!catalogoMusica.length) return;
    indiceActual = modoAleatorio ? Math.floor(Math.random() * catalogoMusica.length) : (indiceActual + 1) % catalogoMusica.length;
    cargarCancion(indiceActual);
    reproducirCancion();
}

function anteriorCancion() {
    if (!catalogoMusica.length) return;
    indiceActual = (indiceActual - 1 + catalogoMusica.length) % catalogoMusica.length;
    cargarCancion(indiceActual);
    reproducirCancion();
}

function actualizarProgreso() {
    if (!audio.duration) return;
    refs.barraProgreso.value = (audio.currentTime / audio.duration) * 100;
    refs.tiempoActual.textContent = formatearTiempo(audio.currentTime);
    refs.duracionTotal.textContent = formatearTiempo(audio.duration);
}

function formatearTiempo(segundos) {
    if (!Number.isFinite(segundos)) return '0:00';
    const m = Math.floor(segundos / 60), s = Math.floor(segundos % 60);
    return `${m}:${String(s).padStart(2, '0')}`;
}

function estadoCarga(texto) {
    return `<div class="estado-carga"><i class="fas fa-circle-notch fa-spin"></i> ${escaparHtml(texto)}</div>`;
}
function imagenLocal(i) { return `img/songs/${(i % 8) + 1}.jpg`; }
function escaparHtml(texto) { const div = document.createElement('div'); div.textContent = texto ?? ''; return div.innerHTML; }
function escaparAtributo(texto) { return escaparHtml(String(texto ?? '')).replace(/"/g, '&quot;'); }
