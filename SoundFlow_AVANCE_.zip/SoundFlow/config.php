<?php

$host = '127.0.0.1';
$db = 'soundflow';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host={$host};dbname={$db};charset={$charset}";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    if (defined('SOUNDFLOW_DIAGNOSTICO') && SOUNDFLOW_DIAGNOSTICO === true) {
        throw $e;
    }
    http_response_code(500);
    header('Content-Type: application/json; charset=UTF-8');
    die(json_encode([
        'success' => false,
        'error' => 'Error de conexión a la base de datos.',
        'detail' => $e->getMessage(),
    ], JSON_UNESCAPED_UNICODE));
}
