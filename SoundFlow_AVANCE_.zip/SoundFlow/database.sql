CREATE DATABASE IF NOT EXISTS soundflow
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE soundflow;

CREATE TABLE IF NOT EXISTS canciones (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    external_id     VARCHAR(80) UNIQUE,
    titulo          VARCHAR(150) NOT NULL,
    artista         VARCHAR(150) NOT NULL,
    album           VARCHAR(150),
    genero          VARCHAR(100),
    duracion        VARCHAR(10),
    imagen_url      VARCHAR(500),
    audio_url       VARCHAR(500),
    store_url       VARCHAR(500),
    fuente          VARCHAR(50) DEFAULT 'local',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_titulo (titulo),
    INDEX idx_artista (artista)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO canciones (external_id, titulo, artista, album, genero, duracion, imagen_url, audio_url, fuente)
VALUES
('local_demo_1','Goteo','Duki','Super Sangre Joven','Urbano','2:44','img/songs/1.jpg','audio/cancion1.mp3','local'),
('local_demo_2','LALA','Myke Towers','LVEU','Urbano','3:17','img/songs/2.jpg','audio/cancion2.mp3','local'),
('local_demo_3','Una Foto Remix','Mesita, Nicki Nicole','Una Foto Remix','Urbano','4:10','img/songs/3.jpg','audio/cancion3.mp3','local')
ON DUPLICATE KEY UPDATE
    titulo = VALUES(titulo),
    artista = VALUES(artista),
    album = VALUES(album),
    genero = VALUES(genero),
    duracion = VALUES(duracion),
    imagen_url = VALUES(imagen_url),
    audio_url = VALUES(audio_url);
