// ==========================================
// SOUNDFLOW - APP PRINCIPAL
// FRONTEND + CONEXIÓN BACKEND
// ==========================================

const API_URL = "http://localhost:8000/backend";


// ==========================================
// DATOS LOCALES DE RESPALDO
// ==========================================

const catalogoMusicaLocal = [
    {
        id: 1,
        titulo: "Goteo",
        artista: "Duki",
        album: "Super Sangre Joven",
        duracion: "2:44",
        img: "img/songs/1.jpg",
        audio: "audio/cancion1.mp3"
    },
    {
        id: 2,
        titulo: "LALA",
        artista: "Myke Towers",
        album: "LVEU",
        duracion: "3:17",
        img: "img/songs/2.jpg",
        audio: "audio/cancion2.mp3"
    },
    {
        id: 3,
        titulo: "Una Foto Remix",
        artista: "Mesita, Nicki Nicole",
        album: "Una Foto Remix",
        duracion: "4:10",
        img: "img/songs/3.jpg",
        audio: "audio/cancion3.mp3"
    }
];


// Esta variable guardará las canciones activas.
let catalogoMusica = [];


// ==========================================
// OBTENER CANCIONES DEL BACKEND
// ==========================================

async function obtenerCancionesBackend() {

    try {

        const response = await fetch(
            `${API_URL}/get_canciones.php`
        );

        if (!response.ok) {

            throw new Error(
                `Error HTTP: ${response.status}`
            );

        }

        const data = await response.json();

        console.log(
            "Respuesta del backend:",
            data
        );


        if (!data.success) {

            throw new Error(
                data.message ||
                "El backend no pudo devolver las canciones."
            );

        }


        if (!Array.isArray(data.data)) {

            throw new Error(
                "El backend no devolvió un arreglo de canciones."
            );

        }


        return data.data;

    } catch (error) {

        console.error(
            "Error al obtener canciones:",
            error
        );

        return [];

    }

}


// ==========================================
// CUANDO EL HTML ESTÉ LISTO
// ==========================================

document.addEventListener(
    "DOMContentLoaded",
    () => {

        // ==========================================
        // ELEMENTOS DEL DOM
        // ==========================================

        const contenedorCanciones =
            document.getElementById(
                "listaCanciones"
            );

        const playerTitulo =
            document.getElementById(
                "playerTitulo"
            );

        const playerArtista =
            document.getElementById(
                "playerArtista"
            );

        const playerImagen =
            document.getElementById(
                "playerImagen"
            );

        const btnPlayer =
            document.getElementById(
                "btnPlayer"
            );

        const btnAnterior =
            document.getElementById(
                "btnAnterior"
            );

        const btnSiguiente =
            document.getElementById(
                "btnSiguiente"
            );

        const btnShuffle =
            document.getElementById(
                "btnShuffle"
            );

        const btnRepeat =
            document.getElementById(
                "btnRepeat"
            );

        const btnLike =
            document.getElementById(
                "btnLike"
            );

        const barraProgreso =
            document.getElementById(
                "barraProgreso"
            );

        const controlVolumen =
            document.getElementById(
                "controlVolumen"
            );

        const tiempoActual =
            document.getElementById(
                "tiempoActual"
            );

        const duracionTotal =
            document.getElementById(
                "duracionTotal"
            );

        const buscador =
            document.getElementById(
                "buscador"
            );


        // ==========================================
        // REPRODUCTOR
        // ==========================================

        const audio = new Audio();

        audio.volume = 0.7;

        let indiceActual = 0;

        let reproduciendo = false;

        let modoAleatorio = false;

        let modoRepetir = false;


        // ==========================================
        // NORMALIZAR DATOS DEL BACKEND
        // ==========================================

        function normalizarCancion(
            cancion,
            indice
        ) {

            return {

                id:
                    cancion.id ??
                    cancion.id_cancion ??
                    indice + 1,

                titulo:
                    cancion.titulo ??
                    cancion.nombre ??
                    cancion.nombre_cancion ??
                    "Sin título",

                artista:
                    cancion.artista ??
                    cancion.nombre_artista ??
                    "Artista desconocido",

                album:
                    cancion.album ??
                    cancion.nombre_album ??
                    "Sin álbum",

                duracion:
                    cancion.duracion ??
                    "0:00",

                img:
                    cancion.img ??
                    cancion.imagen ??
                    `img/songs/${
                        (indice % 3) + 1
                    }.jpg`,

                audio:
                    cancion.audio ??
                    cancion.url_audio ??
                    `audio/cancion${
                        (indice % 3) + 1
                    }.mp3`

            };

        }


        // ==========================================
        // MOSTRAR CANCIONES EN EL DOM
        // ==========================================

        function mostrarCanciones(
            lista
        ) {

            if (!contenedorCanciones) {

                console.error(
                    "No existe #listaCanciones"
                );

                return;

            }


            contenedorCanciones.innerHTML =
                "";


            if (lista.length === 0) {

                contenedorCanciones.innerHTML =
                    `
                    <p>
                        No hay canciones disponibles.
                    </p>
                    `;

                return;

            }


            lista.forEach(
                (cancion, indice) => {

                    const tarjeta =
                        document.createElement(
                            "div"
                        );

                    tarjeta.className =
                        "card";


                    tarjeta.innerHTML = `
                        <div class="card-image">

                            <img
                                src="${cancion.img}"
                                alt="${cancion.titulo}"
                                onerror="this.src='img/songs/1.jpg'"
                            >

                            <button
                                class="play-button"
                                data-indice="${indice}"
                                title="Reproducir"
                            >
                                <i class="fas fa-play"></i>
                            </button>

                        </div>

                        <div class="card-info">

                            <h3>
                                ${cancion.titulo}
                            </h3>

                            <p>
                                ${cancion.artista}
                            </p>

                            <small>
                                ${cancion.album || ""}
                            </small>

                        </div>
                    `;


                    contenedorCanciones
                        .appendChild(
                            tarjeta
                        );

                }
            );


            // ======================================
            // EVENTOS PLAY DE LAS TARJETAS
            // ======================================

            const botones =
                document.querySelectorAll(
                    ".play-button"
                );


            botones.forEach(
                boton => {

                    boton.addEventListener(
                        "click",
                        () => {

                            indiceActual =
                                Number(
                                    boton.dataset.indice
                                );


                            cargarCancion(
                                indiceActual
                            );


                            reproducirCancion();

                        }
                    );

                }
            );

        }


        // ==========================================
        // CARGAR CANCIÓN
        // ==========================================

        function cargarCancion(
            indice
        ) {

            const cancion =
                catalogoMusica[indice];


            if (!cancion) {

                return;

            }


            audio.src =
                cancion.audio;


            if (playerTitulo) {

                playerTitulo.textContent =
                    cancion.titulo;

            }


            if (playerArtista) {

                playerArtista.textContent =
                    cancion.artista;

            }


            if (playerImagen) {

                playerImagen.src =
                    cancion.img;

            }


            if (barraProgreso) {

                barraProgreso.value = 0;

            }


            if (tiempoActual) {

                tiempoActual.textContent =
                    "0:00";

            }


            if (duracionTotal) {

                duracionTotal.textContent =
                    cancion.duracion ||
                    "0:00";

            }

        }


        // ==========================================
        // REPRODUCIR
        // ==========================================

        function reproducirCancion() {

            audio.play()
                .then(
                    () => {

                        reproduciendo =
                            true;


                        if (btnPlayer) {

                            btnPlayer.innerHTML =
                                '<i class="fas fa-pause"></i>';

                        }

                    }
                )
                .catch(
                    error => {

                        console.error(
                            "No se pudo reproducir:",
                            error
                        );

                    }
                );

        }


        // ==========================================
        // PAUSAR
        // ==========================================

        function pausarCancion() {

            audio.pause();

            reproduciendo = false;


            if (btnPlayer) {

                btnPlayer.innerHTML =
                    '<i class="fas fa-play"></i>';

            }

        }


        // ==========================================
        // BOTÓN PLAY / PAUSA
        // ==========================================

        if (btnPlayer) {

            btnPlayer.addEventListener(
                "click",
                () => {

                    if (reproduciendo) {

                        pausarCancion();

                    } else {

                        reproducirCancion();

                    }

                }
            );

        }


        // ==========================================
        // SIGUIENTE
        // ==========================================

        function siguienteCancion() {

            if (
                catalogoMusica.length === 0
            ) {

                return;

            }


            if (modoAleatorio) {

                indiceActual =
                    Math.floor(
                        Math.random() *
                        catalogoMusica.length
                    );

            } else {

                indiceActual++;

                if (
                    indiceActual >=
                    catalogoMusica.length
                ) {

                    indiceActual = 0;

                }

            }


            cargarCancion(
                indiceActual
            );

            reproducirCancion();

        }


        if (btnSiguiente) {

            btnSiguiente.addEventListener(
                "click",
                siguienteCancion
            );

        }


        // ==========================================
        // ANTERIOR
        // ==========================================

        function anteriorCancion() {

            if (
                catalogoMusica.length === 0
            ) {

                return;

            }


            indiceActual--;


            if (indiceActual < 0) {

                indiceActual =
                    catalogoMusica.length - 1;

            }


            cargarCancion(
                indiceActual
            );

            reproducirCancion();

        }


        if (btnAnterior) {

            btnAnterior.addEventListener(
                "click",
                anteriorCancion
            );

        }


        // ==========================================
        // ALEATORIO
        // ==========================================

        if (btnShuffle) {

            btnShuffle.addEventListener(
                "click",
                () => {

                    modoAleatorio =
                        !modoAleatorio;


                    btnShuffle
                        .classList
                        .toggle(
                            "activo",
                            modoAleatorio
                        );

                }
            );

        }


        // ==========================================
        // REPETIR
        // ==========================================

        if (btnRepeat) {

            btnRepeat.addEventListener(
                "click",
                () => {

                    modoRepetir =
                        !modoRepetir;


                    audio.loop =
                        modoRepetir;


                    btnRepeat
                        .classList
                        .toggle(
                            "activo",
                            modoRepetir
                        );

                }
            );

        }


        // ==========================================
        // FAVORITO
        // ==========================================

        if (btnLike) {

            btnLike.addEventListener(
                "click",
                () => {

                    const icono =
                        btnLike
                            .querySelector(
                                "i"
                            );


                    if (icono) {

                        icono
                            .classList
                            .toggle("far");

                        icono
                            .classList
                            .toggle("fas");

                    }


                    btnLike
                        .classList
                        .toggle(
                            "favorito"
                        );

                }
            );

        }


        // ==========================================
        // BARRA DE PROGRESO
        // ==========================================

        audio.addEventListener(
            "timeupdate",
            () => {

                if (!audio.duration) {

                    return;

                }


                const porcentaje =
                    (
                        audio.currentTime /
                        audio.duration
                    ) * 100;


                if (barraProgreso) {

                    barraProgreso.value =
                        porcentaje;

                }


                if (tiempoActual) {

                    tiempoActual.textContent =
                        formatearTiempo(
                            audio.currentTime
                        );

                }


                if (duracionTotal) {

                    duracionTotal.textContent =
                        formatearTiempo(
                            audio.duration
                        );

                }

            }
        );


        // ==========================================
        // MOVER PROGRESO
        // ==========================================

        if (barraProgreso) {

            barraProgreso.addEventListener(
                "input",
                () => {

                    if (!audio.duration) {

                        return;

                    }


                    audio.currentTime =
                        (
                            barraProgreso.value /
                            100
                        ) *
                        audio.duration;

                }
            );

        }


        // ==========================================
        // VOLUMEN
        // ==========================================

        if (controlVolumen) {

            controlVolumen.addEventListener(
                "input",
                () => {

                    audio.volume =
                        Number(
                            controlVolumen.value
                        );

                }
            );

        }


        // ==========================================
        // TERMINÓ CANCIÓN
        // ==========================================

        audio.addEventListener(
            "ended",
            () => {

                if (!modoRepetir) {

                    siguienteCancion();

                }

            }
        );


        // ==========================================
        // BUSCADOR
        // ==========================================

        if (buscador) {

            buscador.addEventListener(
                "input",
                () => {

                    const texto =
                        buscador.value
                            .toLowerCase()
                            .trim();


                    const filtradas =
                        catalogoMusica.filter(
                            cancion =>

                                cancion.titulo
                                    .toLowerCase()
                                    .includes(
                                        texto
                                    )

                                ||

                                cancion.artista
                                    .toLowerCase()
                                    .includes(
                                        texto
                                    )

                        );


                    mostrarCanciones(
                        filtradas
                    );

                }
            );

        }


        // ==========================================
        // FORMATEAR TIEMPO
        // ==========================================

        function formatearTiempo(
            segundos
        ) {

            if (
                !Number.isFinite(
                    segundos
                )
            ) {

                return "0:00";

            }


            const minutos =
                Math.floor(
                    segundos / 60
                );


            const segundosRestantes =
                Math.floor(
                    segundos % 60
                );


            return (
                minutos
                + ":"
                + segundosRestantes
                    .toString()
                    .padStart(
                        2,
                        "0"
                    )
            );

        }


        // ==========================================
        // INICIAR SOUNDFLOW
        // ==========================================

        async function iniciarSoundFlow() {

            if (contenedorCanciones) {

                contenedorCanciones
                    .innerHTML =
                    `
                    <p class="estado-carga">
                        Cargando canciones...
                    </p>
                    `;

            }


            const cancionesBackend =
                await obtenerCancionesBackend();


            if (
                cancionesBackend.length > 0
            ) {

                // Adaptamos los nombres de campos
                // del backend al frontend.

                catalogoMusica =
                    cancionesBackend.map(
                        normalizarCancion
                    );


                console.log(
                    "✅ Canciones cargadas desde backend:",
                    catalogoMusica
                );

            } else {

                // Si falla el backend,
                // usamos los datos locales.

                catalogoMusica =
                    catalogoMusicaLocal;


                console.warn(
                    "⚠️ Se están utilizando las canciones locales."
                );

            }


            mostrarCanciones(
                catalogoMusica
            );


            if (
                catalogoMusica.length > 0
            ) {

                cargarCancion(0);

            }


            console.log(
                "✅ SoundFlow iniciado"
            );

        }


        iniciarSoundFlow();

    }
);